#' myhyper function
#'
#' @param iter Number of iterations
#' @param N Total number of values
#' @param r Differing value number
#' @param n Amount of bars
#'
#' @return A bar graph of the probability for a value to show
#' @export
#'
#' @examples
#' myhyper = function(iter=100,N=20,r=12,n=5)

myhyper <- function(iter,N,r,n){
  sam.mat=matrix(NA,nr=n,nc=iter, byrow=TRUE)
  succ=c()
  for( i in 1:iter){
    sam.mat[,i]=sample(rep(c(1,0),c(r,N-r)),n,replace=FALSE)
    succ[i]=sum(sam.mat[,i])
  }
  succ.tab=table(factor(succ,levels=0:n))
  barplot(succ.tab/(iter), col=rainbow(n+1), main="HYPERGEOMETRIC simulation", xlab="Number of successes")
  succ.tab/iter
}

