#' ntickets
#'
#' @param N Number of seats on a flight
#' @param gamma Probability of a plane truly being overbooked
#' @param p Probability of a person actually showing up
#'
#' @return Two plots of Normal and Discrete Distribution and a list containing N, p, gamma, nc, and nd
#' @export
#'
#' @examples
#' ntickets(400,0.02,0.95)
ntickets <- function(N,gamma,p){
  nd = seq(N,floor(N+N/10), by = 1)
  nc = seq(N,floor(N+N/10), length = 10000)

  tempnd = 1-gamma-pbinom(q=N, size = nd, prob = p)
  tempnc = 1-gamma-pnorm(q=N+.5, mean=nc*p, sd = sqrt(nc*p*(1-p)))

  indnd = which.min(abs(tempnd))
  indnc = which.min(abs(tempnc))

  plot(nd,tempnd, type = "b", col = "black", main = paste("Objective Vs n to find optimal tickets sold\n(",nd[indnd],") gamma = 0.02 N = 200 discrete"), xlab = "n", ylab = "Objective")
  abline(v = nd[indnd], h = tempnd[indnd], col = "red")

  plot(nc, tempnc, lwd = .5, col = "black", main = paste("Objective Vs n to find optimal tickets sold\n(",nc[indnc],") gamma = 0.02 N = 200 continuous"), xlab = "n", ylab = "Objective")
  abline(v = nc[indnc], h = tempnc[indnc], col = "blue")



  list(N = N, Probability = p, gamma = gamma, nd = nd[indnd], nc = nc[indnc])
}
