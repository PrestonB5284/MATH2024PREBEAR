#' myci
#'
#' @param x single sample set
#'
#' @return A 95% confidence interval for the given sample
#' @export
#'
#' @examples myci(x = rnorm(30,mean=10,sd=12))
myci <- function(x){
  t=qt(0.95,length(x))
  ci=c()
  ci[1]=mean(x)-t*sd(x)/sqrt(length(x))
  ci[2]=mean(x)+t*sd(x)/sqrt(length(x))
  ci

  t.test(x,conf.level=0.95)
}
