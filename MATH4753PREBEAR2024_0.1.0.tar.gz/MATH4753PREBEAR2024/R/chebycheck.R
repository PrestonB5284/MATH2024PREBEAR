#' Chebyshev Agreement
#'
#' @param stddev Number of Standard Deviations
#' @param exactprop Exact Proportion of Data
#'
#' @return If the data agrees with Chebyshev's Theorem
#' @export
#'
#' @examples
#' chebycheck(2,0.77)
chebycheck <- function(stddev, exactprop){
  cheby = 1 - (1/(stddev^2))
  ifelse(exactprop >= cheby, print("Agrees with Chebyshev"), print("Disagrees with Chebyshev"))
}
