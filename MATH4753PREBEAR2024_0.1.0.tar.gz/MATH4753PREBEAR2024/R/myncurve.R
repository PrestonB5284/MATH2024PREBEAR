#' Normal Curve Graph Generator
#'
#' @param a the x-axis positive limit
#' @param mu mean value of a data set
#' @param sigma the standard deviation of a data set
#'
#' @return Will produce a graph that shows the normal distribution of the data set
#' @export
#'
#' @examples
#' myncurve(mu = 0, sigma = 1, a = 1.5)
myncurve <- function(mu, sigma, a){
  curve(dnorm(x, mean = mu, sd = sigma), xlim = c(mu-3*sigma, mu + 3*sigma), col = "blue")
  xcurve <- seq(mu - 3*sigma, a, length = 1000)
  ycurve <- dnorm(xcurve, mean = mu, sd = sigma)
  polygon(c(mu-3*sigma,xcurve, a), c(0, ycurve, 0), col = "red")
  prob <- pnorm(a, mean = mu, sd = sigma)
  list(mu = mu, sigma = sigma, a = a, Probability = prob)
}
